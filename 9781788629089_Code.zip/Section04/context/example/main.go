package main

import "github.com/agtorre/go-solutions/section4/context"

func main() {
	context.Initialize()
}
